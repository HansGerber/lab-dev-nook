<?php
/**
 * This demo combines multiple pages of an existing document on new pages with a predefined grid size.
 *
 * Please notice that this will only work for flat, non-dynamic pdf documents.
 */
error_reporting(E_ALL | E_STRICT);

// list some files
$files = glob('../_files/*.pdf');
$files = array_merge($files, glob('../../_files/pdfs/*.pdf'));
$files = array_merge($files, glob('../../_files/pdfs/tektown/*.pdf'));

if (!isset($_GET['f']) || !in_array($_GET['f'], $files)) {
    header("Content-Type: text/html; charset=utf-8");

    foreach ($files AS $path) {
        $name = basename($path);
        echo '<a href="CombinePages.php?f=' . urlencode($path) . '">';
        echo htmlspecialchars($name);
        echo '</a><br />';
    }

    die();
}

// load and register the autoload function
require_once('../../../../library/SetaPDF/Autoload.php');


$perPage = 2;

if ( ($perPage & ($perPage - 1)) != 0) {
    throw new InvalidArgumentException('per page is not a square from 2');
}

$gridSizeX = 1;
$gridSizeY = 1;

// calculate grid size
for ($a = $perPage; $a > 1; $a /= 2) {
    if ($gridSizeX == $gridSizeY) {
        $gridSizeX *= 2;
    } else {
        $gridSizeY = $gridSizeX;
    }
}

// determine the orientation of the new document
if ($gridSizeX == $gridSizeY) {
    $orientation = SetaPDF_Core_PageFormats::ORIENTATION_PORTRAIT;
} else {
    $orientation = SetaPDF_Core_PageFormats::ORIENTATION_LANDSCAPE;
}

// load the original document
$originalDocument = SetaPDF_Core_Document::loadByFilename($_GET['f']);
// get the pages instance of the original document
$originalPages = $originalDocument->getCatalog()->getPages();

// create a new writer for the new document
$writer = new SetaPDF_Core_Writer_Http(basename($_GET['f']), true);

// create a new document
$newDocument = new SetaPDF_Core_Document($writer);

// get the pages instance of the new document
$newPages = $newDocument->getCatalog()->getPages();

// determine how many pages need to be generated
$finalPageCount = ceil(count($originalPages) / $perPage);

// get the page size according to the orientation and page size
$pageSize = SetaPDF_Core_PageFormats::getFormat($originalPages->getPage(1)->getWidthAndHeight(), $orientation);

// calculate the width and height of the object
$xObjectWidth = $pageSize['width'] / $gridSizeX;
$xObjectHeight = $pageSize['height'] / $gridSizeY;

// store the original page count
$originalPageCount = $originalPages->count();

// create the new pages
for ($newPageNumber = 1; $newPageNumber <= $finalPageCount; $newPageNumber++) {
    // create a new page
    $newPage = $newPages->create($pageSize, $orientation);

    // prepare an offset to access the pages of the original document
    $pageOffset = ($newPageNumber - 1) * $perPage;

    // prepare the position
    $x = 0;
    $y = $newPage->getHeight() - $xObjectHeight;

    // iterate through the pages of the original document that should be placed onto the new created page
    for (
        $pageCounter = 1;
        $pageOffset + $pageCounter <= $originalPageCount && $pageCounter <= $perPage;
        $pageCounter++
    ) {
        // get the page as an XObject in the context of the new document
        $xObject = $originalPages->getPage($pageOffset + $pageCounter)->toXObject($newDocument);

        // draw the created object
        $xObject->draw($newPage->getCanvas(), $x, $y, $xObjectWidth, $xObjectHeight);

        // recalculate the current drawing position
        $x += $xObjectWidth;
        if ($x >= $newPage->getWidth()) {
            $x = 0;
            $y -= $xObjectHeight;
        }
    }
}

$newDocument->save(false)->finish();