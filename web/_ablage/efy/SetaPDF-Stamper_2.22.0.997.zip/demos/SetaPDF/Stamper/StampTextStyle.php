<?php
/**
 * This demo will stamp a document with a text with some alternative style elements for text stamp
 */
date_default_timezone_set('Europe/Berlin');
error_reporting(E_ALL | E_STRICT);
ini_set('display_errors', 1);

// load and register the autoload function
require_once('../../../library/SetaPDF/Autoload.php');

// let's get access to the file
$reader = new SetaPDF_Core_Reader_File('../_files/pdfs/tektown/Laboratory-Report.pdf');
// create a HTTP writer
$writer = new SetaPDF_Core_Writer_Http('stamped.pdf', true);
// let's get the document
$document = SetaPDF_Core_Document::load($reader, $writer);

// initiate a stamper instance
$stamper = new SetaPDF_Stamper($document);

// init the font you want to use for the text
$font = SetaPDF_Core_Font_Standard_Helvetica::create($document);

// an other stamp will printed on every page centered with the text "TOP SECRET" rotated
// by 50 degrees as a filled stroke text with transparency
$stamp = new SetaPDF_Stamper_Stamp_Text($font, 100);
$stamp->setText("TOP SECRET");

// set text color to red
$stamp->setTextColor(array(1, 0, 0));

// set rendering mode to 2(fill, then stroke)
// @see PDF reference 32000-1:2008 9.3.6 Text Rendering Mode
$stamp->setRenderingMode(2);

// set transparency
$stamp->setOpacity(0.1);

// add second stamp on all pages on position center_top rotated by 50 degress
$stamper->addStamp($stamp, SetaPDF_Stamper::POSITION_CENTER_MIDDLE, SetaPDF_Stamper::PAGES_ALL, 0, 0, 50);

// stamp the document with all previously added stamps
$stamper->stamp();

// save and finish the resulting document
$document->save()->finish();