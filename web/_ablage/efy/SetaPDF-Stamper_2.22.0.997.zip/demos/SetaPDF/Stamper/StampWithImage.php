<?php
/**
 * This demo will stamp a document with a image
 */
date_default_timezone_set('Europe/Berlin');
error_reporting(E_ALL | E_STRICT);
ini_set('display_errors', 1);

// load and register the autoload function
require_once('../../../library/SetaPDF/Autoload.php');

// let's get access to the file
$reader = new SetaPDF_Core_Reader_File('../_files/pdfs/Fact-Sheet-without-personalization.pdf');
// create a HTTP writer
$writer = new SetaPDF_Core_Writer_Http('stamped.pdf', true);
// let's get the document
$document = SetaPDF_Core_Document::load($reader, $writer);

// initiate a stamper instance
$stamper = new SetaPDF_Stamper($document);

// initiate the stamps
$stamp = new SetaPDF_Stamper_Stamp_Image(SetaPDF_Core_Image::getByPath('../_files/pdfs/camtown/Logo.png'));
// set height (and width until no setWidth is set the ratio will retain)
$stamp->setHeight(23);

// add stamp to stamper on position LEFT_TOP for all pages
$stamper->addStamp($stamp, SetaPDF_Stamper::POSITION_LEFT_TOP, SetaPDF_Stamper::PAGES_ALL, 43, -38);

// stamp the document with all previously added stamps
$stamper->stamp();

// save and finish the resulting document
$document->save()->finish();