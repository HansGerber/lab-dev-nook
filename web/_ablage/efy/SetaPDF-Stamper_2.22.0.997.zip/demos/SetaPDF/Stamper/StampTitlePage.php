<?php
/**
 * This demo will add a title page and stamp it with some information
 */
date_default_timezone_set('Europe/Berlin');
error_reporting(E_ALL | E_STRICT);
ini_set('display_errors', 1);

// load and register the autoload function
require_once('../../../library/SetaPDF/Autoload.php');

// let's get access to the file
$reader = new SetaPDF_Core_Reader_File('../_files/pdfs/Brand-Guide.pdf');
// create a HTTP writer
$writer = new SetaPDF_Core_Writer_Http('stamped.pdf', true);
// let's get the document
$document = SetaPDF_Core_Document::load($reader, $writer);

// get pages helper
$pages = $document->getCatalog()->getPages();
// create a page in format A4 but don't append it
$page = $pages->create(SetaPDF_Core_PageFormats::A4, SetaPDF_Core_PageFormats::ORIENTATION_PORTRAIT, false);
// prepend the created page
$pages->prepend($page);

// initiate a stamper instance
$stamper = new SetaPDF_Stamper($document);


// init the font you want to use for the text
$font = SetaPDF_Core_Font_Standard_Helvetica::create($document);
// initiate the text stamp
$stamp = new SetaPDF_Stamper_Stamp_Text($font, 23);
// fill the stamp with text
$stamp->setText(
    "SetaPDF_Stamper-TitlePage-Demo\n"
        . "From: " . $_SERVER['REMOTE_ADDR'] . "\n"
        . "User: Tester\n"
        . "Date: " . date("Y-m-d H:i")
);
// center the text in textbox
$stamp->setAlign(SetaPDF_Core_Text::ALIGN_CENTER);
// define line height to 35
$stamp->setLineHeight(35);
// add stamp to stamper
$stamper->addStamp($stamp, SetaPDF_Stamper::POSITION_CENTER_MIDDLE, SetaPDF_Stamper::PAGES_FIRST);

// now we want to insert an image above the text

// define which image we want to stamp
$image = SetaPDF_Core_Image::getByPath('../_files/pdfs/camtown/Logo.png');
// initiate a image stamp
$stamp = new SetaPDF_Stamper_Stamp_Image($image);
// stretch image stamp
$stamp->setDimensions(150, 30);
// Add stamp to stamper centered on the first page with an y translation of +80
$stamper->addStamp($stamp, SetaPDF_Stamper::POSITION_CENTER_MIDDLE, SetaPDF_Stamper::PAGES_FIRST, 0, 120);

// stamp the document with all previously added stamps
$stamper->stamp();

// save and finish the resulting document
$document->save(true)->finish();