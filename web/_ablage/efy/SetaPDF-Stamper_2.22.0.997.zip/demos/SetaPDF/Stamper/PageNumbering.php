<?php
/**
 * This demo shows you how to add page numbers to a document.
 *
 * Additionally a thin line will be placed above the text.
 */
date_default_timezone_set('Europe/Berlin');
error_reporting(E_ALL | E_STRICT);
ini_set('display_errors', 1);

// load and register the autoload function
require_once('../../../library/SetaPDF/Autoload.php');

// create a file writer
$writer = new SetaPDF_Core_Writer_Http("page-numbering-demo.pdf", true);
// load document by filename
$document = SetaPDF_Core_Document::loadByFilename('../_files/pdfs/lenstown/products/All.pdf', $writer);

// create a stamper instance for the document
$stamper = new SetaPDF_Stamper($document);

// create a font for this document
$font = SetaPDF_Core_Font_Standard_Helvetica::create($document);

// create a stamp with the created font and fontsize of 10 points
$stamp = new SetaPDF_Stamper_Stamp_Text($font, 10);
$stamp->setTextColor('#6d6f72');

// Callback to set the pagenumbers for each page
function callbackForPageNumbering($pageNumber, $pageCount, $page, SetaPDF_Stamper_Stamp $stamp) {
    // set the text for the stamp object before stamping
    $stamp->setText("Page $pageNumber of $pageCount");

    // if the callback don't return true the page won't be stamped
    return true;
}

// add the stamp and assign the callback function
$stamper->addStamp($stamp, array(
    'position' => SetaPDF_Stamper::POSITION_RIGHT_BOTTOM,
    'translateX' => -29,
    'translateY' => 30,
    'callback' => 'callbackForPageNumbering'
));

// In the next step we create an xobject stamp object which we use to draw a
// simple line above the page numbering. We initate it with a temporary width
// of 10 points and stretch it a runtime depending on the page width.

$lineWidth = .2;

// create a XObject
$xObject = SetaPDF_Core_XObject_Form::create($document, array(0, 0, 10, $lineWidth));
// get the Canvas
$canvas = $xObject->getCanvas();
// set the collor and draw a line
$canvas
    ->setColor('#39b54b')
    ->path()
        ->setLineWidth($lineWidth)
    ->draw()
        ->line(0, $lineWidth/2, 10, $lineWidth/2);

// create the stamp object for the XObject
$xObjectStamp = new SetaPDF_Stamper_Stamp_XObject($xObject);
$xObjectStamp->setHeight($lineWidth);

// add the line 4 points above the page numbering text and ensure the correct width through a callback
$stamper->addStamp($xObjectStamp, array(
    'position' => SetaPDF_Stamper::POSITION_RIGHT_BOTTOM,
    'translateX' => -29,
    'translateY' => 30 + $stamp->getHeight() + 4,
    'callback' => function($pageNumber, $pageCount, SetaPDF_Core_Document_Page $page, SetaPDF_Stamper_Stamp $stamp) {
        $stamp->setWidth($page->getWidth() - 29 * 2);
        return true;
    }
));

// stamp the document with all added stamps of the stamper
$stamper->stamp();
// save the file and finish the writer (e.g. file handler will closed)
$document->save()->finish();
